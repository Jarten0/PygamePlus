class Camera():
    def __init__(self) -> None:
        self.xpos = 0
        self.ypos = 0
        self.xdefault = 0
        self.ydefault = 0
        self.xoffset = 0
        self.yoffset = 0
